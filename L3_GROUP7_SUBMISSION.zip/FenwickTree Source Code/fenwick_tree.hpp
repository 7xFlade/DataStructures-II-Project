#ifndef FENWICK_TREE_H
#define FENWICK_TREE_H
#include <vector>

class FenwickTree
{
private:
    std::vector<int> BIT;

public:
    FenwickTree(int size) : BIT(size + 1, 0) {} // Initialize the BIT to 0
    void update(int index, int value);
    int query(int index);
    int rangeQuery(int start, int end);
    void updateFenwickTree(int& indexToChange, int& newValue );
};
void rangeQueryComparison() ;
// Binary Search Tree (BST)
class BST 
{
private:
    struct TreeNode {
        int val;
        TreeNode* left;
        TreeNode* right;
        TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    };
    TreeNode* root;

    // Helper function to insert a value into BST
    TreeNode* insert(TreeNode* node, int value);

    // Helper function to find sum of values up to a given index in BST
    int query(TreeNode* node, int index);

public:
    BST() : root(nullptr) {}
    void insert(int value);
    int query(int index);
};

#endif // FENWICK_TREE_H
