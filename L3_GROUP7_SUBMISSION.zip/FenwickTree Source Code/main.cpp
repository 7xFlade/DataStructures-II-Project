/*
 Creator:  Moiz Zulfiqar, Zain Hatim, Ahmed Khalid, Muhammad Taqi
 Date of creation: 05-03-2024 (DD/MM/YYYY)
 Description: Implementation of Fenwick Tree (Binary Indexed Tree) in C++.
 Fenwick Tree is a data structure that allows you to efficiently update elements and calculate prefix sums in a table of numbers.
 The Fenwick Tree supports two operations:
 1. Update: Add a value to an element at a given index.
 2. Query: Calculate the sum of elements in the range [0, index].
 The Fenwick Tree uses O(n) space and supports both operations in O(log n) time complexity.
 The Fenwick Tree is also known as Binary Indexed Tree (BIT).
 Time Complexity: O(log n) for both update and query operations.
*/

#include <iostream>
#include <ctime>
#include <cstdlib>
#include "fenwick_tree.hpp"
#include <vector>
#include <math.h>
#include <string.h>
#include <cmath>

using namespace std;

void visualizeFenwickTree(const vector<int>& fenwickTree) {
    int levels = log2(fenwickTree.size() - 1) + 1;
    int maxWidth = 4 * (1 << (levels - 1));
    vector<vector<string>> treeRepresentation(levels, vector<string>(maxWidth, " "));

    for (int i = 1; i < fenwickTree.size(); ++i) {
        int level = log2(i & -i);
        int index = (i & -i) - 1 + (i >> level);
        treeRepresentation[level][2 * index + 1] = to_string(fenwickTree[i]);
    }

    for (int i = 0; i < levels; ++i) {
        for (int j = 0; j < maxWidth; ++j) {
            cout << treeRepresentation[i][j];
        }
        cout << endl;
    }
}

void FenwickTree::update(int index, int value)
{
    index++; // Convert 0-based index to 1-based index
    while (index < BIT.size())
    {
        BIT[index] += value;
        index += index & -index; // Move to the parent in the tree
    }
}
void FenwickTree::updateFenwickTree(int& indexToChange, int& newValue)
{
    // Get the current value at the index
    int oldValue = query(indexToChange) - query(indexToChange - 1);
    // Calculate the difference
    int diff = newValue - oldValue;

    // Update the Fenwick Tree with the difference
    update(indexToChange, diff);
}

int FenwickTree::query(int index)
{
    index++; // Convert 0-based index to 1-based index
    int sum = 0;
    while (index > 0)
    {
        sum += BIT[index];       // Add the value at the current index
        index -= index & -index; // Move to the parent in the tree
    }
    return sum;
}
int FenwickTree::rangeQuery(int start, int end)
{
    return query(end) - query(start - 1);
}

void rangeQueryComparison()
{
    const int SIZE = 100000; // Lock the size for the range query
    FenwickTree fenwickTree(SIZE);

    // Generate random array elements
    std::srand(std::time(nullptr));
    std::vector<int> arr(SIZE);
    for (int i = 0; i < SIZE; ++i)
    {
        arr[i] = std::rand() % 100; // Random values from 0 to 99
        fenwickTree.update(i, arr[i]);
    }

    int start, end;
    std::cout << "Enter the starting index for the range query (0-based index): ";
    std::cin >> start;
    std::cout << "Enter the ending index for the range query (0-based index): ";
    std::cin >> end;

    // Perform range query using Fenwick tree
    if (start >= 0 && start <= end && end < SIZE)
    {
        std::clock_t startFenwick = std::clock();
        int fenwickResult = fenwickTree.rangeQuery(start, end);
        std::clock_t endFenwick = std::clock();
        double fenwickTime = static_cast<double>(endFenwick - startFenwick) / CLOCKS_PER_SEC;

        std::cout << "Sum of elements in the range [" << start << ", " << end << "] using Fenwick Tree: " << fenwickResult << std::endl;
        std::cout << "Time taken for Fenwick Tree query: " << fenwickTime << " seconds" << std::endl;

        // Perform range query on the array
        std::clock_t startArray = std::clock();
        int arrayResult = 0;
        for (int i = start; i <= end; ++i)
        {
            arrayResult += arr[i];
        }
        std::clock_t endArray = std::clock();
        double arrayTime = static_cast<double>(endArray - startArray) / CLOCKS_PER_SEC;

        std::cout << "Sum of elements in the range [" << start << ", " << end << "] using normal array: " << arrayResult << std::endl;
        std::cout << "Time taken for normal array query: " << arrayTime << " seconds" << std::endl;
    }
    else
    {
        std::cout << "Invalid range. Range should be within [0, " << SIZE - 1 << "]." << std::endl;
    }
}
BST::TreeNode *BST::insert(TreeNode *node, int value)
{
    if (node == nullptr)
        return new TreeNode(value);
    if (value <= node->val)
        node->left = insert(node->left, value);
    else
        node->right = insert(node->right, value);
    return node;
}

int BST::query(TreeNode *node, int index)
{
    if (node == nullptr || index < 0)
        return 0;
    if (index == 0)
        return node->val;
    return query(node->left, index - 1) + query(node->right, index - 1) + node->val;
}

void BST::insert(int value)
{
    root = insert(root, value);
}

int BST::query(int index)
{
    return query(root, index);
}
FenwickTree fenwick_tree()
{
    int n;
    std::cout << "Enter the size of the array: ";
    std::cin >> n;

    FenwickTree fenwickTree(n);

    std::cout << "Enter the elements of the array:\n";
    for (int i = 0; i < n; i++)
    {
        int element;
        std::cin >> element;
        fenwickTree.update(i, element);
    }

    int queryIndex;
    std::cout << "Enter the index for range query (0-based index): ";
    std::cin >> queryIndex;

    if (queryIndex < 0 || queryIndex >= n)
    {
        std::cout << "Invalid query index. Please enter a valid index within the range [0, " << n - 1 << "]." << std::endl;
        return fenwickTree;
    }

    int result = fenwickTree.query(queryIndex);

    std::cout << "Sum of elements in the range [0, " << queryIndex << "]: " << result << std::endl;
    return fenwickTree;
}

void BstFenwickComparison(){
    const int size = 100000; // Example test case size
    std::vector<int> elements(size);
    for (int i = 0; i < size; ++i)
    {
        elements[i] = rand() % 100; // Generate random integers between 0 and 99
    }

    // Binary Search Tree
    BST bst;
    clock_t start = clock();
    for (int i = 0; i < size; ++i)
    {
        bst.insert(elements[i]);
    }
    int bst_sum = bst.query(size - 1);
    clock_t end = clock();
    double bst_time = double(end - start) / CLOCKS_PER_SEC;

    // Fenwick Tree
    FenwickTree fenwickTree(size);
    start = clock();
    for (int i = 0; i < size; ++i)
    {
        fenwickTree.update(i, elements[i]);
    }
    int fenwick_sum = fenwickTree.query(size - 1);
    end = clock();
    double fenwick_time = double(end - start) / CLOCKS_PER_SEC;

    // Output time taken for both operations
    std::cout << "Test size: " << size << std::endl;
    std::cout << "Time taken by Binary Search Tree: " << bst_time << " seconds" << std::endl;
    std::cout << "Time taken by Fenwick Tree: " << fenwick_time << " seconds" << std::endl;

    // Compare the sum results if needed
    std::cout << "Binary Search Tree Sum: " << bst_sum << std::endl;
    std::cout << "Fenwick Tree Sum: " << fenwick_sum << std::endl;
}

int main()
{
    int choice;
    choice = 444;

    while (choice != 0)
    {
        std::cout << "Enter operation preference" << std::endl;
        std::cout << "1 : form a fenwick tree" << std::endl;
        std::cout << "2 : Perform a comparison between BST and Fenwick tree" << std::endl;
        std::cout << "3 : Perform a range query with an array" << std::endl;
        std::cout << "4 : Visualise A fenwick Tree" << endl;
        std::cout << "0 : Exit" << std::endl;

        std::cin >> choice;

        if (choice == 1)
        {
            FenwickTree Fenwick = fenwick_tree();
            int reperform;
            std::cout << "If you would like to update your array or perform an operation again, enter the number 1 else 0 to exit" << std::endl;
            std::cin >> reperform;
            if (reperform == 1)
            {
                while (reperform == 1)
                {
                    int indextochange, newvalue;
                    std::cout << "Enter the index of your array that you would like to change:" << std::endl;
                    std::cin >> indextochange;
                    std::cout << "Enter the new value you would like to enter:" << std::endl;
                    std::cin >> newvalue;
                    Fenwick.updateFenwickTree(indextochange, newvalue);
                    std::cout << "if you would like to update another value enter the number 1 again. Otherwise enter the number 0 to return to main menu, 2 for time comparison and 3 for running the range query. :" << std::endl;
                    std::cin >> reperform;
                }
                int queryIndex;
                std::cout << "Enter the index for range query (0-based index): ";
                std::cin >> queryIndex;

                int result = Fenwick.query(queryIndex);

                std::cout << "Sum of elements in the range [0, " << queryIndex << "]: " << result << std::endl;
            }
        }
        else if (choice == 2)
        {
            BstFenwickComparison();
        }
        else if (choice == 3)
        {
            rangeQueryComparison();
        }
        else if (choice == 4)
        {
            int choice;
            cout << "Enter the size of your array :" << endl;
            cin >> choice;
            std::vector<int> fenwickTree;
            for(int i = 0; i < choice+1; i++)
            {
                fenwickTree.push_back(rand() % 100);
            }
            std::cout << "Fenwick Tree Visualization:" << endl;
            visualizeFenwickTree(fenwickTree);
        }
        else if (choice == 0)
        {
            break;
        }
        else 
        {
            std::cout << "The option you entered is not valid" << std::endl;
        }
    }
    // prompt so that the terminal dosn't immediately disappear
    std::cout << "Press Enter to exit...";
    std::cin.ignore();
    std::cin.get();
    return 0;
}
